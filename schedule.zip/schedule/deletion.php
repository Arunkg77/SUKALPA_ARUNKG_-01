<?php
$size=sizeof($_POST);
$j=1;
for($i=1;$i<=$size;$i++,$j++)
{
    $index="b".$j;
if(isset($_POST[$index]))
    $b_id[$i]=$_POST[$index];
else
$i--;
}
$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'dummy_db');

for($k=1;$k<=$size;$k++)
{
    $q="delete from schedule_list where id=".$b_id[$k];
    mysqli_query($con,$q);

}
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deletion</title>

    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        h1 {
            color: #0066cc;
            text-align: center;
            animation: fadeIn 1s ease-in-out;
        }

        p {
            font-size: 18px;
            color: #009933;
            text-align: center;
            animation: slideIn 1s ease-in-out;
        }

        a {
            display: block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #ff6600;
            color: #fff;
            text-decoration: none;
            text-align: center;
            border-radius: 5px;
            transition: background-color 0.3s ease-in-out;
        }

        a:hover {
            background-color: #cc3300;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
    </style>
</head>
<body>
    <h1>Select to delete</h1>
    <p>
        <?php 
            echo $size." Records deleted";
        ?>
    </p>
    <p>Go back to the home page. <a href="deleteForm.php">Click Here</a></p>

    <script>
    </script>
</body>
</html>
