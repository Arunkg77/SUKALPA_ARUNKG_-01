<?php

$con=mysqli_connect('localhost','root');
mysqli_select_db($con,'dummy_db');
$q="Select * from schedule_list";
$result=mysqli_query($con,$q);
$num=mysqli_num_rows($result);
mysqli_close($con);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager's Portal</title>
    <style>
    
    body {
    font-family: 'Cinzel Decorative', cursive;
    background-color: #f2f2f2;
    text-align: center;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    height: 100vh;
    background-image: url('annn.jpg');
    
}

h1 {
    color: #fff;
    background-color: #800000; /* Maroon */
    padding: 10px;
    border-radius: 5px;
    margin: 20px;
    backdrop-filter: blur(10px);
}

table {
    border-collapse: collapse;
    width: 100%;
    margin: auto;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    overflow: hidden;
    animation: fadeIn 1s ease-in-out;
}

@keyframes fadeIn {
    0% {
        opacity: 0;
        transform: translateY(-20px);
    }
    100% {
        opacity: 1;
        transform: translateY(0);
    }
}

th, td {
    padding: 15px;
    text-align: left;
}

th {
    background-color: #D4AF37; /* Gold */
    color: #fff;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

input[type="checkbox"] {
    transform: scale(1.5);
}

input[type="submit"] {
    background-color: #800000; /* Maroon */
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
}

input[type="submit"]:hover {
    background-color: #660000; /* Darker Maroon */
}

    </style>
</head>
<body>
    <h1> Slot Management</h1>
    <form action="deletion.php" method="post">
        <table>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Description</th>
                <th>start_datetime</th>
                <th>End_datetime</th>
            </tr>
            <?php
            for ($i = 1; $i <= $num; $i++) {
                $row = mysqli_fetch_array($result);
                ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['title']; ?></td>
                    <td><?php echo $row['description']; ?></td>
                    <td><?php echo $row['start_datetime']; ?></td>
                    <td><?php echo $row['end_datetime']; ?></td>

                    <td><input type="checkbox" value="<?php echo $row['id']; ?>" name="b<?php echo $i?>"></td>

                </tr>
                <?php
            }
            ?>
            <tr>
                <td colspan="5"><input type="submit" value="Delete"></td>
            </tr>
        </table>
    </form>
</body>
</html>
