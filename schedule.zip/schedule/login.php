<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Meet-Up</title>
  <style>
    body {
      font-family: 'Arial', sans-serif;
      background: url('annn.jpg') no-repeat center center fixed;
      background-size: cover;
      color: #fff;
      overflow: hidden;
      margin: 0;
      padding: 0;
    }

    .container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      height: 100vh;
      background: rgba(0, 0, 0, 0.5);
    }

    .forms-container, .intros-container {
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
      width: 80%;
      max-width: 1200px;
    }

    .form-control, .intro-control {
      background-color: rgba(255, 255, 255, 0.1);
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
      margin: 10px;
    }

    form {
      display: flex;
      flex-direction: column;
    }

    label, input {
      margin-bottom: 10px;
    }

    input {
      padding: 10px;
      border: none;
      border-radius: 5px;
      background-color: rgba(255, 255, 255, 0.8);
    }

    button {
      padding: 10px;
      border: none;
      border-radius: 5px;
      background-color: #28a745;
      color: white;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    button:hover {
      background-color: #218838;
    }

    .intro-control__inner {
      text-align: center;
    }

    #signup-btn, #signin-btn {
      margin-top: 10px;
    }

    @keyframes float {
      0% {
        transform: translateY(0);
      }
      50% {
        transform: translateY(-10px);
      }
      100% {
        transform: translateY(0);
      }
    }

    .forest-animation {
      animation: float 3s infinite ease-in-out;
    }
  </style>
</head>
<body>
  
  <?php
  session_start();

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      $dbHost = 'localhost';
      $dbName = 'dummy_db';
      $dbUser = 'root';
      $dbPass = '';

      $conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      }

      if (isset($_POST['username']) && isset($_POST['password'])) {
          $username = $_POST['username'];
          $password = $_POST['password'];

          $username = $conn->real_escape_string($username);
          $password = $conn->real_escape_string($password);

          $query = "SELECT * FROM login WHERE username = '$username' AND password = '$password'";
          $result = $conn->query($query);

          if ($result->num_rows === 1) {
              $_SESSION['username'] = $username;
              header("Location: index.php");
              exit();
          } else {
              $error = "Invalid username or password";
          }
      }

      if (isset($_POST['username1']) && isset($_POST['password1'])) {
          $username1 = $_POST['username1'];
          $password1 = $_POST['password1'];

          if ($username1 === 'arun'  && $password1 === '1234') {
              $_SESSION['username1'] = $username1;
              header("Location: deleteForm.php");
              exit();
          } else {
              $error = "Invalid username or password";
          }
      }
      $conn->close();
  }
  ?>

  <div class="container">
    <div class="forms-container">
      <div class="form-control signup-form">
        <form method="post">
        <div class="intro-control signin-intro">
        <div class="intro-control__inner">
          <h2>Welcome!!</h2>
          <p>Register now to secure your spot! Don't miss out on this incredible experience.

Join us and be part of something amazing. We can't wait to see you there!</p>
          
        </div>
      </div>
          <label for="username">Username:</label>
          <input type="text" name="username" required>
          <label for="password">Password:</label>
          <input type="password" name="password" required>
          <button type="submit"><span class="emoji">🔒</span> Sign-in to register slot</button>
        </form>
      </div>
      <div class="form-control signin-form">
      <div class="intro-control signup-intro">
        <div class="intro-control__inner">
          <h2>Administrator's Portal!</h2>
          <p>
We are thrilled to have you here! Come join us and make this day unforgettable.

Let's collaborate and create lasting memories together. Your participation makes all the difference! </p>
         
        </div>
      </div>
        <form method="post">
          <label for="username1">Username:</label>
          <input type="text" name="username1" required>
          <label for="password1">Password:</label>
          <input type="password" name="password1" required>
          <button type="submit"><span class="emoji">🔒</span> Sign-in to Managers portal.</button>
        </form>
      </div>
    </div>
    <div class="intros-container">
      
      
    </div>
  </div>
  <script>
    document.getElementById('signup-btn').addEventListener('click', function() {
      document.querySelector('.signup-form').classList.toggle('forest-animation');
    });

    document.getElementById('signin-btn').addEventListener('click', function() {
      document.querySelector('.signin-form').classList.toggle('forest-animation');
    });
  </script>
</body>
</html>
