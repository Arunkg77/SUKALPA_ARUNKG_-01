<?php
require_once('db-connect.php');
require 'php_mailer/src/Exception.php';
require 'php_mailer/src/PHPMailer.php';
require 'php_mailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

extract($_GET);

$allday = isset($allday);

$title = isset($_GET['title']) ? $_GET['title'] : null;
$description = isset($_GET['description']) ? $_GET['description'] : null;
$start_datetime = isset($_GET['start_datetime']) ? $_GET['start_datetime'] : null;
$end_datetime = isset($_GET['end_datetime']) ? $_GET['end_datetime'] : null;
$token = isset($_GET['token']) ? $_GET['token'] : null;

$token = bin2hex(random_bytes(16));

if ($title && $description && $start_datetime && $end_datetime && $token ) {
    
    $sql = "INSERT INTO `schedule_list` (`title`, `description`, `start_datetime`, `end_datetime`, `token`) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssss', $title, $description, $start_datetime, $end_datetime, $token);
    $stmt->execute();
    $stmt->close();

    try {
        
        $mail = new PHPMailer(true);

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'arunkgudagi77@gmail.com'; 
        $mail->Password = 'rxlemfklgwehkifp'; 
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('arunkgudagi77@gmail.com', 'Arun');
        $mail->addAddress('arunkgudagi77@gmail.com', 'Robot Name');

        $mail->isHTML(true);

        $mail->Subject = 'Auditorium Slot Booking Confirmed';
; 

        $mail->Body = "
            <html>
            <head>
            </head>
            <body>
                <h1 style='color:red'> Thank You , Your Slot is confirmed </h1>
            </body>
            </html>";

        $mail->send();
        echo "<script> alert('Schedule submitted for approval, and email sent.'); location.replace('./') </script>";
        header("Location: http://localhost:8081/schedule/");
        exit();
        } 
        catch (Exception $e) {
            echo "<pre>";
            echo "An Error occurred while sending the email.<br>";
            echo "Error: " . $e->getMessage() . "<br>";
            echo "</pre>";
    }
} 

$conn->close();
?>
